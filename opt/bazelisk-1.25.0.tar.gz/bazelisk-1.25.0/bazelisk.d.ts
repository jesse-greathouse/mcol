export function getNativeBinary(): string;
