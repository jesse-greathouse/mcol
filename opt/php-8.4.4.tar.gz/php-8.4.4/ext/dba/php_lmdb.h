#ifndef PHP_LMDB_H
#define PHP_LMDB_H

#ifdef DBA_LMDB

#include "php_dba.h"
#include <lmdb.h>

DBA_FUNCS(lmdb);

#endif

#endif
